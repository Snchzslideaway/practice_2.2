import tkinter as tk
from tkinter import ttk, messagebox
import requests
import psutil
import json
import os

class PracticeApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Учебная практика 2.2 - Настольное приложение")
        self.root.geometry("800x600")

        self.notebook = ttk.Notebook(root)
        self.notebook.pack(expand=True, fill="both", padx=10, pady=10)

        self.create_task1_tab()
        self.create_task2_tab()
        self.create_task3_tab()
        self.create_task4_tab()

    def create_task1_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Доступность сайтов")

        btn = ttk.Button(tab, text="Проверить сайты", command=self.check_sites)
        btn.pack(pady=10)

        self.txt_sites = tk.Text(tab, height=15)
        self.txt_sites.pack(padx=10, pady=10, fill="both")

    def check_sites(self):
        urls = [
            "https://github.com", "https://binance.com",
            "https://tomtit.tomsk.ru", "https://typicode.com",
            "https://tomtit-tomsk.ru"
        ]
        self.txt_sites.delete("1.0", tk.END)
        for url in urls:
            try:
                r = requests.get(url, timeout=5, verify=False)
                status = "доступен" if r.status_code == 200 else "ошибка"
                self.txt_sites.insert(tk.END, f"{url} – {status} – {r.status_code}\n")
            except:
                self.txt_sites.insert(tk.END, f"{url} – не доступен\n")


    def create_task2_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Системный монитор")

        self.lbl_cpu = ttk.Label(tab, text="CPU: --%", font=("Arial", 14))
        self.lbl_cpu.pack(pady=10)

        self.lbl_ram = ttk.Label(tab, text="RAM: --%", font=("Arial", 14))
        self.lbl_ram.pack(pady=10)

        self.lbl_disk = ttk.Label(tab, text="Disk: --%", font=("Arial", 14))
        self.lbl_disk.pack(pady=10)
        ttk.Button(tab, text="Обновить", command=self.update_monitor).pack(pady=10)

    def update_monitor(self):
        self.lbl_cpu.config(text=f"Загрузка CPU: {psutil.cpu_percent()}%")
        ram = psutil.virtual_memory()
        self.lbl_ram.config(text=f"RAM: {ram.percent}% (Использовано {ram.used // 1024**2} MB)")
        self.lbl_disk.config(text=f"Диск: {psutil.disk_usage('/').percent}%")

    def create_task3_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Курсы валют")

        btn_load = ttk.Button(tab, text="Загрузить курсы", command=self.get_currency)
        btn_load.pack(pady=5)

        self.tree_valute = ttk.Treeview(tab, columns=("Code", "Value"), show="headings", height=10)
        self.tree_valute.heading("Code", text="Код валюты")
        self.tree_valute.heading("Value", text="Курс (руб)")
        self.tree_valute.pack(fill="both", padx=10, pady=5)

    def get_currency(self):
        try:
            url = "https://cbr-xml-daily.ru"
            data = requests.get(url, verify=False).json()['Valute']
            for i in self.tree_valute.get_children(): self.tree_valute.delete(i)
            for code, info in data.items():
                self.tree_valute.insert("", tk.END, values=(code, info['Value']))
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось загрузить данные: {e}")

    # --- ЗАДАНИЕ 4: GITHUB API ---
    def create_task4_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="GitHub Search")

        ttk.Label(tab, text="Введите логин GitHub:").pack(pady=5)
        self.ent_user = ttk.Entry(tab)
        self.ent_user.pack(pady=5)

        ttk.Button(tab, text="Найти профиль", command=self.search_github).pack(pady=5)
        self.txt_github = tk.Text(tab, height=10)
        self.txt_github.pack(padx=10, pady=10, fill="both")

    def search_github(self):
        user = self.ent_user.get()
        if not user: return
        try:
            r = requests.get(f"https://github.com{user}")
            if r.status_code == 200:
                d = r.json()
                info = f"Имя: {d.get('name')}\nРепозиториев: {d.get('public_repos')}\nFollowers: {d.get('followers')}"
                self.txt_github.delete("1.0", tk.END)
                self.txt_github.insert(tk.END, info)
            else:
                messagebox.showwarning("Внимание", "Пользователь не найден")
        except:
            messagebox.showerror("Ошибка", "Проблема с сетью")

if __name__ == "__main__":
    root = tk.Tk()
    app = PracticeApp(root)
    root.mainloop()
